package ejercicio04;

public interface ICaducable {
	
	public void avisarCaducidad ();

}
